# Manage app config

from django.apps import AppConfig


class PollsConfig(AppConfig):
    name = 'polls'
